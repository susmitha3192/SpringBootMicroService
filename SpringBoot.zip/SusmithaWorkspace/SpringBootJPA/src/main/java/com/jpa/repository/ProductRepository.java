package com.jpa.repository;

import org.springframework.data.repository.CrudRepository;

import com.jpa.Product;

public interface ProductRepository extends CrudRepository<Product,Integer>{

}
