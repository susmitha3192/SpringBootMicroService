package com.jpa.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestMapping;

import com.jpa.Product;
import com.jpa.repository.ProductRepository;

@Service
public class ProductService {
@Autowired
ProductRepository productRepos;
	
	public List<Product> getAllProducts(){
		List<Product> products=new ArrayList<Product>();
		productRepos.findAll().forEach(products::add);
		return products;
 }
	public void addProduct(Product product) {
		productRepos.save(product);
	}
	public Optional<Product> getProduct(Integer productId) {
		// TODO Auto-generated method stub
		return productRepos.findById(productId);
	}
	
	public void deleteProduct(int productId) {
		productRepos.deleteById(productId);
	}
	
	public void updateProduct(int productId,Product product){
		productRepos.save(product);
	}
		
}
