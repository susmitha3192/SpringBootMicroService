package com.product;

import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.product.service.ProductService;

@RestController
@RequestMapping("/products")
public class ProductController {
	@Autowired
	ProductService prodService;
	@RequestMapping("/getAllProducts")
	public List<Product> getProducts(){
	  return prodService.getAllProducts();
	}
	
@RequestMapping(method=RequestMethod.POST,value="/insertProduct")	
public List<Product> insertProduct(@RequestBody Product product){
	 
	return prodService.addProduct(product);
	
}
@RequestMapping("/getProduct/{productId}")
public Product getProuctByProductId(@PathVariable("productId") Integer productId) {
	return prodService.getProduct(productId);
}
@RequestMapping(value="/delete/{productId}",method=RequestMethod.DELETE)
public List<Product> deleteProduct(@PathVariable("productId") Integer productId) {
	
	return prodService.deleteProduct(productId);
}
@RequestMapping(value="/update/{productId}",method=RequestMethod.PUT)
public List<Product> updateProduct(@PathVariable("productId") Integer productId,@RequestBody Product product){
	return prodService.updateProduct(productId, product);
}
@RequestMapping("/getProducts")
public ResponseEntity<List<Product>> getProducts2(){
	List<Product> list=prodService.getAllProducts();
  return new ResponseEntity<List<Product>>(list,HttpStatus.FOUND);
}
}
