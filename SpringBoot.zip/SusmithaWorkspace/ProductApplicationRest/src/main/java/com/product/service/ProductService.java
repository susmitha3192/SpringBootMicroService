package com.product.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestMapping;

import com.product.Product;
@Service
public class ProductService {

	List<Product> list=new ArrayList(Arrays.asList(
			  new Product(100,"Computer",30000,130),
			  new Product(101,"Keypad",1000,140),
			  new Product(102,"mouse",500,150),
			  new Product(103,"Monitor",10000,160),
			  new Product(104,"laptop",50000,170),
			  new Product(105,"Mobile",60000,180)
			  ));
	public List<Product> getAllProducts(){
	  return list;
 }
	public List<Product> addProduct(Product product) {
		list.add(product);
		return list;
	}
	public Product getProduct(Integer productId) {
		// TODO Auto-generated method stub
		return list.stream().filter(t->t.getProductId()==(productId)).findFirst().get();
	}
	
	public List<Product> deleteProduct(int productId) {
		list.removeIf(t->t.getProductId()==productId);
		return list;
	}
	
	public List<Product> updateProduct(int productId,Product product){
		for(int i=0;i<list.size();i++) {
			Product prod=list.get(i);
			if(prod.getProductId()==productId) {
				list.set(i, product);
			}
		}
		return list;
		
	}
}
