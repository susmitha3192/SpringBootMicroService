function validate(){
	var name=ocument.getElementById("name").value;
	if(name==""){
		alert("Please enter name");
		return false;
	}
	else{
		return true;
	}
}