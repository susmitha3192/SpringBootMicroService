package com.demo.controller;

import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.web.servlet.error.ErrorController;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class HomeController implements ErrorController {
	
	public final static String url="/error";
	@RequestMapping("/")
	public String Home()
	{
		return "Welcome to SpringBoot Application";
	}

	@Override
	public String getErrorPath() {
		// TODO Auto-generated method stub
		return url;
	}
	
	@RequestMapping(value=url)
	public String errorMsg() {
		return "HomeController Error Message!!!";
	}
}
