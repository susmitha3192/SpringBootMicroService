package com.demo;

import java.util.Arrays;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@SpringBootApplication(scanBasePackages="com.demo")
public class PmsApplication {
	
	public static void main(String[] args) {
		ApplicationContext ctx=SpringApplication.run(PmsApplication.class, args);
	    String[] beanNames=ctx.getBeanDefinitionNames();
	    Arrays.sort(beanNames);
	    System.out.println("***********All the Predefined Beans provided by SpringBoot***************");
	    for(String bean:beanNames) {
	    	System.out.println(bean);
	    }
	}

}
