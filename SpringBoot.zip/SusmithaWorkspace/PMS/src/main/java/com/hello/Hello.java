package com.hello;


import org.springframework.boot.web.servlet.error.ErrorController;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
@RestController
public class Hello {
	
	@RequestMapping("/sayHello")
	public String sayHello() {
		return "Hello! How are you!!";
	}
	
}
