package com.jpa;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.jpa.service.ProductService;

@RestController
@RequestMapping("/products")
public class ProductController {
	@Autowired
	ProductService prodService;
	@RequestMapping("/getAllProducts")
	public List<Product> getProducts(){
	  return prodService.getAllProducts();
	}
	
@RequestMapping(method=RequestMethod.POST,value="/insertProduct")	
public void insertProduct(@RequestBody Product product){	 
	 prodService.addProduct(product);	
}
@RequestMapping("/getProduct/{productId}")
public Product getProuctByProductId(@PathVariable("productId") Integer productId) {
	return prodService.getProduct(productId);
}
@RequestMapping(value="/delete/{productId}",method=RequestMethod.DELETE)
public void deleteProduct(@PathVariable("productId") Integer productId) {
	
	 prodService.deleteProduct(productId);
}
@RequestMapping(value="/update/{productId}",method=RequestMethod.PUT)
public void updateProduct(@PathVariable("productId") Integer productId,@RequestBody Product product){
	 prodService.updateProduct(productId, product);
}
@RequestMapping("/getProducts")
public ResponseEntity<List<Product>> getProducts2(){
	List<Product> list=prodService.getAllProducts();
  return new ResponseEntity<List<Product>>(list,HttpStatus.FOUND);
}
}
